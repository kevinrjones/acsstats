create
    definer = cricketarchive@`%` procedure team_records_innings_extras_overall(IN match_type varchar(20),
                                                                               IN ground_id int, IN homecountry_id int,
                                                                               IN homeOrAway int,
                                                                               IN startDate mediumtext,
                                                                               IN endDate mediumtext,
                                                                               IN season varchar(10),
                                                                               IN matchResult int, IN minimum_total int,
                                                                               IN sort_by int,
                                                                               IN sort_direction varchar(5))
begin

    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @minimum_total = minimum_total;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;


    select t.Name                              team,
           extras,
           byes,
           legbyes,
           wides,
           noballs,
           Penalty                             penalties,
           i.Total,
           i.Overs,
           g.KnownAs,
           o.Name                              opponents,
           m.MatchStartDate,
           truncate((extras / total) * 100, 1) percentage
    from innings i
             join matches m on i.MatchId = m.id
             join Teams t on t.id = i.TeamId
             join Teams o on o.id = i.OpponentsId
             join grounds g on g.id = m.LocationId and g.MatchType = m.MatchType
             join ExtraMatchDetails emd on m.Id = emd.MatchId and emd.teamid = m.HomeTeamId
    where m.MatchType = @match_type
      and extras >= @minimum_total
      AND ((@ground_id = 0) OR (locationid = @ground_id))
      AND ((@homecountry_id = 0) OR (m.homecountryid = @homecountry_id))
      AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
      AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
      AND ((@season = '0') OR (@season = seriesDate))
      and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
      and ((@matchresult = 0) OR (emd.Result & @matchresult))

    order by (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 13 AND @sort_direction = 'ASC' THEN byes END),
             (CASE WHEN @sort_by = 13 AND @sort_direction = 'DESC' THEN byes END) DESC,
             (CASE WHEN @sort_by = 14 AND @sort_direction = 'ASC' THEN legbyes END),
             (CASE WHEN @sort_by = 14 AND @sort_direction = 'DESC' THEN legbyes END) DESC,
             (CASE WHEN @sort_by = 15 AND @sort_direction = 'ASC' THEN wides END),
             (CASE WHEN @sort_by = 15 AND @sort_direction = 'DESC' THEN wides END) DESC,
             (CASE WHEN @sort_by = 16 AND @sort_direction = 'ASC' THEN noballs END),
             (CASE WHEN @sort_by = 16 AND @sort_direction = 'DESC' THEN noballs END) DESC,
             (CASE WHEN @sort_by = 23 AND @sort_direction = 'ASC' THEN penalties END),
             (CASE WHEN @sort_by = 23 AND @sort_direction = 'DESC' THEN penalties END) DESC,
             (CASE WHEN @sort_by = 24 AND @sort_direction = 'ASC' THEN extras END),
             (CASE WHEN @sort_by = 24 AND @sort_direction = 'DESC' THEN extras END) DESC,
             (CASE WHEN @sort_by = 25 AND @sort_direction = 'ASC' THEN percentage END),
             (CASE WHEN @sort_by = 25 AND @sort_direction = 'DESC' THEN percentage END) DESC,
             team;
end;

