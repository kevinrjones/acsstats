create
    definer = cricketarchive@`%` procedure fow_partnership_list_by_innings(IN team_id INT, IN opponent_id INT,
                                                                           IN match_type VARCHAR(20), IN ground_id INT,
                                                                           IN homecountry_id INT, IN homeOrAway INT,
                                                                           IN startDate LONG, IN endDate LONG,
                                                                           IN season VARCHAR(10), IN matchResult INT,
                                                                           IN runs_limit INT, IN sort_by INT,
                                                                           IN sort_direction VARCHAR(5))
begin

    set @team_id = team_id;
    set @opponents_id = opponent_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @homeOrAway = homeOrAway;
    set @startdate = startDate;
    set @enddate = endDate;
    set @season = season;
    set @matchresult = matchResult;
    set @runs_limit = runs_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;

    with tmp_fow as (select f.Partnership,
                            f.MatchType,
                            f.Id,
                            f.MatchId,
                            f.TeamId,
                            f.OpponentsId,
                            f.Innings,
                            f.Wicket,
                            f.PlayerIds,
                            f.PlayerNames,
                            f.CurrentScore,
                            f.Fifty,
                            f.Hundred,
                            f.Unbroken,
                            f.Multiple,
                            f.Partial
                     from (select *
                           from FallOfWickets
                           where PlayerIds != '0000000100000001'
                             and Multiple = false
                             and MatchId in
                                 (select id
                                  from matches
                                  where id in (select matchid from FallOfWickets)
                                    and matchtype = @match_type
                                    AND ((@team_id = 0) OR (teamid = @team_id))
                                    AND ((@opponents_id = 0) OR (OpponentsId = @opponents_id))
                                    AND ((@ground_id = 0) OR (LocationId = @ground_id))
                                    AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
                                    AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                                    AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
                                    AND ((@season = '0') OR (@season = seriesDate))
                                 )) as f
                              join matches m on m.id = f.matchid
                              join extramatchdetails emd
                                   on emd.MatchId = m.Id
                                       and emd.TeamId = f.TeamId
                                       and ((@matchResult = 0) OR (emd.result & @matchResult))
                                       and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
    )
    select PlayerIds,
           p1.FullName as player1,
           p2.FullName as player2,
           Partnership as runs,
           Wicket,
           Unbroken       unbroken1,
           Unbroken       unbroken2,
           Innings,
           t.Name         Team,
           O.Name         Opponents,
           g.KnownAs,
           m.MatchStartDate
    from tmp_fow
             join players p1 on p1.Id = substr(tmp_fow.PlayerIds, 1, 8)
             join players p2 on p2.Id = substr(tmp_fow.PlayerIds, 9, 8)
             join teams t on t.Id = tmp_fow.TeamId
             join teams o on o.Id = tmp_fow.OpponentsId
             join matches m on m.id = tmp_fow.MatchId
             join grounds g on g.Id = m.LocationId
    where Partnership > @runs_limit

    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN PlayerNames END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN PlayerNames END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN Opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN Opponents END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN runs END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN runs END) DESC,
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'ASC' THEN MatchStartDateAsOffset END),
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'DESC' THEN MatchStartDateAsOffset END) DESC,
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'ASC' THEN KnownAs END),
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'DESC' THEN KnownAs END) DESC,
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'ASC' THEN innings END),
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'DESC' THEN innings END) DESC,
             Partnership desc, MatchStartDateAsOffset, PlayerNames;
end;

