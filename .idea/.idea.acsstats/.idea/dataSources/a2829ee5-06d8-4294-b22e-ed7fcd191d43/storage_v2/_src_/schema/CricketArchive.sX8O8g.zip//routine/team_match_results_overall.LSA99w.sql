create
    definer = cricketarchive@`%` procedure team_match_results_overall(IN match_type VARCHAR(20), IN ground_id INT,
                                                                      IN homecountry_id INT, IN homeOrAway INT,
                                                                      IN startDate LONG, IN endDate LONG,
                                                                      IN season VARCHAR(10), IN matchResult INT,
                                                                      IN minimum_total INT, IN sort_by INT,
                                                                      IN sort_direction VARCHAR(5))
begin

    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @minimum_total = minimum_total;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;


    select t.Name team, o.Name opponents, MatchStartDate, HowMuch, emd.Result, m.VictoryType
    from ExtraMatchDetails emd
             join matches m on m.id = emd.MatchId
             join teams t on t.id = emd.teamid
        and ((matchresult = 0) OR (emd.result & matchresult))
        and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
             join teams o on o.id = emd.OpponentsId
    where m.matchtype = @match_type
      AND ((@ground_id = 0) OR (locationid = @ground_id))
      AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
      AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
      AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
      AND ((@season = '0') OR (@season = seriesDate))
      and HowMuch > @minimum_total


    order by (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN HowMuch END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN HowMuch END) DESC,
             m.MatchStartDateAsOffset;
end;

