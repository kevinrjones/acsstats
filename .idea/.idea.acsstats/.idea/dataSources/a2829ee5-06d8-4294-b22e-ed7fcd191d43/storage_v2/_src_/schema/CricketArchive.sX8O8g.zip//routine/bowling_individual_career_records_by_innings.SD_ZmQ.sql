create
    definer = cricketarchive@`%` procedure bowling_individual_career_records_by_innings(IN team_id INT,
                                                                                        IN opponents_id INT,
                                                                                        IN match_type VARCHAR(20),
                                                                                        IN ground_id INT,
                                                                                        IN homecountry_id INT,
                                                                                        IN homeOrAway INT,
                                                                                        IN startDate LONG,
                                                                                        IN endDate LONG,
                                                                                        IN season VARCHAR(10),
                                                                                        IN matchResult INT,
                                                                                        IN wickets_limit INT,
                                                                                        IN sort_by INT,
                                                                                        IN sort_direction VARCHAR(5))
begin
    set @team_id = team_id;
    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @wickets_limit = wickets_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;

    select players.FullName,
           players.SortNamePart,
           T.Name                     team,
           coalesce(bd.Balls, 0)   as playerballs,
           coalesce(bd.Maidens, 0) as playermaidens,
           coalesce(bd.Runs, 0)    as playerruns,
           coalesce(bd.wickets, 0) as playerwickets,
           bd.InningsNumber,
           O.Name                     opponents,
           g.KnownAs               as ground,
           matches.matchdesignator,
           matches.MatchStartDate     matchDate,
           matches.seriesdate,
           matches.BallsPerOver
    from BowlingDetails bd
             join teams t on T.id = bd.teamid
        and bd.matchtype = @match_type
        and t.MatchType = bd.MatchType
             join teams o on O.id = bd.opponentsid
        and o.matchtype = bd.MatchType
             join players on players.id = bd.PlayerId
             join matches on matches.id = bd.matchid
        and matches.matchtype = bd.MatchType
             join grounds g on g.id = matches.LocationId
        and g.MatchType = bd.MatchType
        AND ((@ground_id = 0) OR (g.id = @ground_id))
        AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
        AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
        AND ((@endDate = 0) OR (@endDate >= matchStartDateAsOffset))
        AND ((@season = '0') OR (@season = matches.seriesDate))
        AND ((@opponents_id = 0) OR (@opponents_id = bd.OpponentsId))
        AND ((@team_id = 0) OR (@team_id = bd.TeamId))
             join extramatchdetails emd1
                  on emd1.MatchId = Matches.Id
                      and emd1.TeamId = bd.TeamId
                      and ((@matchresult = 0) OR (emd1.result & @matchresult))
             join extramatchdetails emd2
                  on emd2.MatchId = matches.Id
                      and emd2.TeamId = bd.TeamId
                      and ((@homeOrAway = 0) OR (emd2.HomeAway & @homeOrAway))


    where bd.DidBowl = true
      and bd.matchtype = @match_type
      and bd.Wickets >= @wickets_limit


    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN sortnamepart END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN sortnamepart END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN playerruns END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN playerruns END) DESC,
             (CASE WHEN @sort_by = 5 AND @sort_direction = 'ASC' THEN playerwickets END),
             (CASE WHEN @sort_by = 5 AND @sort_direction = 'DESC' THEN playerwickets END) DESC,
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'ASC' THEN playerballs END),
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'DESC' THEN playerballs END) DESC,
             (CASE WHEN @sort_by = 35 AND @sort_direction = 'ASC' THEN InningsNumber END),
             (CASE WHEN @sort_by = 35 AND @sort_direction = 'DESC' THEN InningsNumber END) DESC,
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'ASC' THEN KnownAs END),
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'DESC' THEN KnownAs END) DESC,
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'ASC' THEN MatchStartDateAsOffset END),
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'DESC' THEN MatchStartDateAsOffset END) DESC,
             (CASE WHEN @sort_by = 47 AND @sort_direction = 'ASC' THEN maidens END),
             (CASE WHEN @sort_by = 47 AND @sort_direction = 'DESC' THEN maidens END) DESC,
             playerwickets desc, playerruns, MatchStartDateAsOffset;
end;

