create
    definer = cricketarchive@`%` procedure team_records_total_extras_for_team(IN match_type varchar(20), IN team_id int,
                                                                              IN ground_id int, IN homecountry_id int,
                                                                              IN homeOrAway int,
                                                                              IN startDate mediumtext,
                                                                              IN endDate mediumtext,
                                                                              IN season varchar(10), IN matchResult int,
                                                                              IN minimum_total int, IN sort_by int,
                                                                              IN sort_direction varchar(5))
begin

    set @team_id = team_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @minimum_total = minimum_total;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;


    select extras.Name                                      team,
           games.played,
           extras.runs,
           extras.extras,
           extras.byes,
           extras.legbyes,
           extras.wides,
           extras.noballs,
           extras.penalties,
           extras.wickets,
           extras.balls,
           truncate((extras.Extras / extras.runs) * 100, 1) percentage
    from (select teamid, count(*) played
          from ExtraMatchDetails as emd
                   join matches m on m.Id = emd.MatchId and emd.teamid = @team_id
          where m.matchtype = @match_type
            AND ((@ground_id = 0) OR (locationid = @ground_id))
            AND ((@homecountry_id = 0) OR (m.homecountryid = @homecountry_id))
            AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
            AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
            AND ((@season = '0') OR (@season = seriesDate))
            and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
            and ((@matchresult = 0) OR (emd.Result & @matchresult))
          group by teamid) as games
             left join (
        select t.Id,
               t.Name,
               sum(i.Total)       runs,
               sum(i.extras)      extras,
               sum(i.Byes)        byes,
               sum(i.LegByes)     legbyes,
               sum(i.Wides)       wides,
               sum(i.Noballs)     noballs,
               sum(i.Penalty)     penalties,
               sum(i.Wickets)     wickets,
               sum(i.BallsBowled) balls
        from Matches m
                 join innings i on m.id = i.MatchId
                 join teams t on t.id = i.TeamId and t.MatchType = m.MatchType
                 join ExtraMatchDetails emd on m.Id = emd.MatchId and emd.teamid = m.HomeTeamId
        where m.MatchType = @match_type
          AND ((@ground_id = 0) OR (locationid = @ground_id))
          AND ((@homecountry_id = 0) OR (m.homecountryid = @homecountry_id))
          AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
          AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
          AND ((@season = '0') OR (@season = seriesDate))
          and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
          and ((@matchresult = 0) OR (emd.Result & @matchresult))
        group by i.teamid) as extras
                       on games.teamid = extras.Id

    where extras >= @minimum_total

    order by (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN runs END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN runs END) DESC,
             (CASE WHEN @sort_by = 5 AND @sort_direction = 'ASC' THEN wickets END),
             (CASE WHEN @sort_by = 5 AND @sort_direction = 'DESC' THEN wickets END) DESC,
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'ASC' THEN balls END),
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'DESC' THEN balls END) DESC,
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'ASC' THEN games.played END),
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'DESC' THEN games.played END) DESC,
             (CASE WHEN @sort_by = 13 AND @sort_direction = 'ASC' THEN byes END),
             (CASE WHEN @sort_by = 13 AND @sort_direction = 'DESC' THEN byes END) DESC,
             (CASE WHEN @sort_by = 14 AND @sort_direction = 'ASC' THEN legbyes END),
             (CASE WHEN @sort_by = 14 AND @sort_direction = 'DESC' THEN legbyes END) DESC,
             (CASE WHEN @sort_by = 15 AND @sort_direction = 'ASC' THEN wides END),
             (CASE WHEN @sort_by = 15 AND @sort_direction = 'DESC' THEN wides END) DESC,
             (CASE WHEN @sort_by = 16 AND @sort_direction = 'ASC' THEN noballs END),
             (CASE WHEN @sort_by = 16 AND @sort_direction = 'DESC' THEN noballs END) DESC,
             (CASE WHEN @sort_by = 23 AND @sort_direction = 'ASC' THEN penalties END),
             (CASE WHEN @sort_by = 23 AND @sort_direction = 'DESC' THEN penalties END) DESC,
             (CASE WHEN @sort_by = 24 AND @sort_direction = 'ASC' THEN extras END),
             (CASE WHEN @sort_by = 24 AND @sort_direction = 'DESC' THEN extras END) DESC,
             (CASE WHEN @sort_by = 25 AND @sort_direction = 'ASC' THEN percentage END),
             (CASE WHEN @sort_by = 25 AND @sort_direction = 'DESC' THEN percentage END) DESC,
             team;
end;

