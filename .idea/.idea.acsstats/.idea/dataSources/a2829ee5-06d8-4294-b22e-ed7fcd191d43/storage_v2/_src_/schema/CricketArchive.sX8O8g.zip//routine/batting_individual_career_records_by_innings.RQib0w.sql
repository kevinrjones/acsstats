create
    definer = cricketarchive@`%` procedure batting_individual_career_records_by_innings(IN team_id int,
                                                                                        IN opponents_id int,
                                                                                        IN match_type varchar(20),
                                                                                        IN ground_id int,
                                                                                        IN homecountry_id int,
                                                                                        IN homeOrAway int,
                                                                                        IN startDate mediumtext,
                                                                                        IN endDate mediumtext,
                                                                                        IN season varchar(10),
                                                                                        IN matchResult int,
                                                                                        IN runs_limit int,
                                                                                        IN sort_by int,
                                                                                        IN sort_direction varchar(5))
begin
    set @team_id = team_id;
    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @runs_limit = runs_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;
    
    
    select players.FullName,
           players.SortNamePart,
           0                    as bat1,
           0                    as bat2,
           battingdetails.score as playerscore,
           battingdetails.notout,
           battingdetails.position,
           battingdetails.balls,
           battingdetails.fours,
           battingdetails.sixes,
           battingdetails.minutes,
           battingdetails.captain,
           battingdetails.wicketkeeper,
           T.Name                  team,
           O.Name                  opponents,
           matches.matchdesignator,
           matches.MatchStartDate matchDate,
           matches.seriesdate,
           battingdetails.InningsNumber,
           battingdetails.dismissal,
           bowler.fullname      as bowler,
           fielder.fullname     as fielder,
           g.KnownAs            as ground
    from battingdetails
             join teams t on T.id = battingdetails.teamid
        and battingdetails.matchtype = @match_type
        and t.MatchType = battingDetails.MatchType
             join teams o on O.id = battingdetails.opponentsid
        and o.matchtype = battingDetails.MatchType
             join players on players.id = battingdetails.PlayerId
             left outer join players bowler on bowler.playerid = battingdetails.bowlerid
             left outer join players fielder on fielder.playerid = battingdetails.fielderid
             join matches on matches.id = BattingDetails.matchid
        and matches.matchtype = battingDetails.MatchType
             join grounds g on g.Id = matches.LocationId
        and g.MatchType = BattingDetails.MatchType
        AND ((@ground_id = 0) OR (g.Id = @ground_id))
        AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
        AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
        AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
        AND ((season = '0') OR (season = matches.seriesDate))
        AND ((@opponents_id = 0) OR (@opponents_id = BattingDetails.OpponentsId))
        AND ((@team_id = 0) OR (@team_id = BattingDetails.TeamId))
             join extramatchdetails emd1
                  on emd1.MatchId = Matches.Id
                      and emd1.TeamId = BattingDetails.TeamId
                      and ((@matchResult = 0) OR (emd1.result & @matchResult))
             join extramatchdetails emd2
                  on emd2.MatchId = matches.Id
                      and emd2.TeamId = BattingDetails.TeamId
                      and ((@homeOrAway = 0) OR (emd2.HomeAway & @homeOrAway))


    where BattingDetails.Score >= @runs_limit


    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN players.sortnamepart END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN players.sortnamepart END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'ASC' THEN Balls END),
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'DESC' THEN Balls END) DESC,
             (CASE WHEN @sort_by = 33 AND @sort_direction = 'ASC' THEN Fours END),
             (CASE WHEN @sort_by = 33 AND @sort_direction = 'DESC' THEN Fours END) DESC,
             (CASE WHEN @sort_by = 34 AND @sort_direction = 'ASC' THEN Sixes END),
             (CASE WHEN @sort_by = 34 AND @sort_direction = 'DESC' THEN Sixes END) DESC,
             (CASE WHEN @sort_by = 38 AND @sort_direction = 'ASC' THEN Minutes END),
             (CASE WHEN @sort_by = 38 AND @sort_direction = 'DESC' THEN Minutes END) DESC,
             (CASE WHEN @sort_by = 35 AND @sort_direction = 'ASC' THEN InningsNumber END),
             (CASE WHEN @sort_by = 35 AND @sort_direction = 'DESC' THEN InningsNumber END) DESC,
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'ASC' THEN KnownAs END),
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'DESC' THEN KnownAs END) DESC,
             (CASE WHEN @sort_by = 22 AND @sort_direction = 'ASC' THEN MatchStartDateAsOffset END),
             (CASE WHEN @sort_by = 22 AND @sort_direction = 'DESC' THEN MatchStartDateAsOffset END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN score END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN score END) DESC,
             score desc, NotOut desc, MatchStartDateAsOffset;
end;

