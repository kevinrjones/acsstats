create
    definer = cricketarchive@`%` procedure team_records_results_against_opponents(IN match_type VARCHAR(20),
                                                                                  IN opponents_id INT, IN ground_id INT,
                                                                                  IN homecountry_id INT,
                                                                                  IN homeOrAway INT, IN startDate LONG,
                                                                                  IN endDate LONG,
                                                                                  IN season VARCHAR(10),
                                                                                  IN matchResult INT,
                                                                                  IN minimum_total INT, IN sort_by INT,
                                                                                  IN sort_direction VARCHAR(5))
begin

    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @minimum_total = minimum_total;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;


    select t.name as               team,
           o.name as               opponents,
           m.VictoryType,
           m.howmuch,
           m.MatchStartDate,
           m.MatchStartDateAsOffset,
           g.KnownAs,
           t.id   as               teamid,
           o.id   as               opponentsid,
           COALESCE(m.WhoWonId, 0) whowonid,
           m.TossTeamId            tossteamid
    from matches m
             join ExtraMatchDetails emd on m.Id = emd.MatchId
             join teams T on t.id = emd.teamid and t.MatchType = emd.MatchType and emd.MatchId = m.id
             join teams O on o.id = emd.OpponentsId and t.MatchType = emd.MatchType and emd.MatchId = m.id
             join grounds g on g.id = m.LocationId and g.MatchType = m.MatchType
    where m.MatchType = @match_type
      AND emd.OpponentsId = @opponents_id
      AND ((@ground_id = 0) OR (locationid = @ground_id))
      AND ((@homecountry_id = 0) OR (m.homecountryid = @homecountry_id))
      AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
      AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
      AND ((@season = '0') OR (@season = seriesDate))
      and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
      and ((@matchresult = 0) OR (emd.Result & @matchresult))
      and m.howmuch > @minimum_total

    order by (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'ASC' THEN MatchStartDateAsOffset END),
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'DESC' THEN MatchStartDateAsOffset END) DESC,
             (CASE WHEN @sort_by = 18 AND @sort_direction = 'DESC' THEN VictoryType END) desc,
             (CASE WHEN @sort_by = 18 AND @sort_direction = 'DESC' THEN HowMuch END) DESC,
             (CASE WHEN @sort_by = 18 AND @sort_direction = 'ASC' THEN VictoryType END),
             (CASE WHEN @sort_by = 18 AND @sort_direction = 'ASC' THEN HowMuch END),
             MatchStartDateAsOffset;
end;

