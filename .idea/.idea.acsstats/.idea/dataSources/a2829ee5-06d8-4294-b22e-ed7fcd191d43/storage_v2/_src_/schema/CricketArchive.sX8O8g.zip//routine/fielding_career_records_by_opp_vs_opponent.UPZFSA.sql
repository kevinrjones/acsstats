create
    definer = cricketarchive@`%` procedure fielding_career_records_by_opp_vs_opponent(IN opponents_id INT,
                                                                                      IN match_type VARCHAR(20),
                                                                                      IN ground_id INT,
                                                                                      IN homecountry_id INT,
                                                                                      IN homeOrAway INT,
                                                                                      IN startDate LONG,
                                                                                      IN endDate LONG,
                                                                                      IN season VARCHAR(10),
                                                                                      IN matchResult INT,
                                                                                      IN dismissals_limit INT,
                                                                                      IN sort_by INT,
                                                                                      IN sort_direction VARCHAR(5))
begin

    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @dismissals_limit = dismissals_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;

    with tmp_field as (select f.MatchId,
                              f.playerid,
                              f.MatchType,
                              f.caughtf,
                              f.CaughtWk,
                              f.stumped,
                              f.Dismissals,
                              f.InningsNumber,
                              f.TeamId,
                              f.OpponentsId
                       from (select *
                             from Fielding
                             where matchid in
                                   (select id
                                    from matches
                                    where id in (select matchid from Fielding)
                                      and matchtype = @match_type
                                      and OpponentsId = @opponents_id
                                      AND ((@ground_id = 0) OR (@ground_id = LocationId))
                                      AND ((@homecountry_id = 0) OR (@homecountry_id = homecountryid))
                                      AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                                      AND ((@endDate = 0) OR (@endDate >= matchStartDateAsOffset))
                                      AND ((@season = '0') OR (@season = seriesDate))
                                   )) as f
                                join matches m on m.id = f.matchid
                                join extramatchdetails emd
                                     on emd.MatchId = m.Id
                                         and emd.TeamId = f.TeamId
                                         and ((@matchResult = 0) OR (emd.result & @matchResult))
                                         and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
    )
    select p.FullName                         as name,
           teams.teams                           team,
           o.Name                                opponents,
           ''                                    Year,
           ''                                    ground,
           ''                                    CountryName,
           played.matches,
           inn.innings,
           tf.dismissals,
           tf.caughtkeeper + tf.caughtfielder as caught,
           tf.stumpings,
           tf.caughtkeeper,
           tf.caughtfielder,
           best.Dismissals                    as bestDismissals,
           best.CaughtF                       as bestCaughtFielder,
           best.CaughtWk                      as bestCaughtKeeper,
           best.Stumped                       as bestStumpings
    from (select tf.playerid,
                 MatchType,
                 tf.OpponentsId,
                 sum(tf.caughtf)    caughtfielder,
                 sum(tf.CaughtWk)   caughtkeeper,
                 sum(tf.stumped)    stumpings,
                 sum(tf.Dismissals) dismissals
          from tmp_field tf
          group by tf.PlayerId, tf.MatchType, tf.OpponentsId) as tf
             join players p on p.Id = tf.PlayerId
             join Teams o on o.Id = OpponentsId and o.MatchType = tf.MatchType
             left join (select PlayerId,
                               OpponentsId,
                               count(*) matches
                        from tmp_field
                        where InningsNumber = 1
                        group by PlayerId, OpponentsId) played
                       on played.PlayerId = tf.PlayerId and played.OpponentsId = tf.OpponentsId
             left join (
        select rn,
               PlayerId,
               TeamId,
               OpponentsId,
               MatchType,
               Dismissals,
               CaughtWk,
               Stumped,
               CaughtF
        from (select PlayerId,
                     teamid,
                     opponentsid,
                     f.MatchType,
                     f.Dismissals,
                     f.CaughtWk,
                     f.Stumped,
                     f.CaughtF,
                     row_number() over (
                         partition by PlayerId, OpponentsId
                         order by Dismissals desc
                         ) as rn
              from tmp_field f) best
        where rn = 1
    ) best on best.PlayerId = tf.PlayerId and best.matchtype = tf.MatchType
        and best.OpponentsId = tf.OpponentsId
             left join (select tid.playerid, tid.OpponentsId, count(*) innings
                        from Innings i
                                 join matches m on i.MatchId = m.id
                                 join (select matchid, teamid, PlayerId, OpponentsId
                                       from tmp_field
                                       where InningsNumber = 1
                        ) tid
                        where i.Matchid = tid.MatchId
                          and i.TeamId <> tid.TeamId
                        group by tid.PlayerId, tid.OpponentsId) as inn
                       on inn.PlayerId = best.PlayerId and inn.OpponentsId = best.OpponentsId
             left join
         (select pt.playerid, t.matchtype, GROUP_CONCAT(t.name SEPARATOR ', ') as teams
          from playersteams pt
                   join teams t on pt.teamid = t.id
          group by pt.playerid, t.matchtype)
             as teams on teams.playerid = tf.playerid and teams.matchtype = tf.MatchType
    where tf.dismissals > @dismissals_limit

    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN sortnamepart END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN sortnamepart END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'ASC' THEN played.matches END),
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'DESC' THEN played.matches END) DESC,
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'ASC' THEN inn.innings END),
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'DESC' THEN inn.innings END) DESC,
             (CASE WHEN @sort_by = 26 AND @sort_direction = 'ASC' THEN tf.dismissals END),
             (CASE WHEN @sort_by = 26 AND @sort_direction = 'DESC' THEN tf.dismissals END) DESC,
             (CASE WHEN @sort_by = 27 AND @sort_direction = 'ASC' THEN caught END),
             (CASE WHEN @sort_by = 27 AND @sort_direction = 'DESC' THEN caught END) DESC,
             (CASE WHEN @sort_by = 28 AND @sort_direction = 'ASC' THEN stumpings END),
             (CASE WHEN @sort_by = 28 AND @sort_direction = 'DESC' THEN stumpings END) DESC,
             (CASE WHEN @sort_by = 29 AND @sort_direction = 'ASC' THEN CaughtWk END),
             (CASE WHEN @sort_by = 29 AND @sort_direction = 'DESC' THEN CaughtWk END) DESC,
             (CASE WHEN @sort_by = 30 AND @sort_direction = 'ASC' THEN CaughtF END),
             (CASE WHEN @sort_by = 30 AND @sort_direction = 'DESC' THEN CaughtF END) DESC,
             (CASE WHEN @sort_by = 31 AND @sort_direction = 'ASC' THEN bestDismissals END),
             (CASE WHEN @sort_by = 31 AND @sort_direction = 'DESC' THEN bestDismissals END) DESC,
             tf.Dismissals desc, opponents;

end;

