create
    definer = cricketarchive@`%` procedure team_records_by_opp_against_opponents(IN match_type VARCHAR(20),
                                                                                 IN opponents_id INT, IN ground_id INT,
                                                                                 IN homecountry_id INT,
                                                                                 IN homeOrAway INT, IN startDate LONG,
                                                                                 IN endDate LONG, IN season VARCHAR(10),
                                                                                 IN matchResult INT, IN sort_by INT,
                                                                                 IN sort_direction VARCHAR(5))
begin

    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;


    with tmp as (select m.matchtype, m.id, emd.teamid, Result, OpponentsId
                 from Matches as m
                          join ExtraMatchDetails emd on m.Id = emd.MatchId
                 where m.matchtype = @match_type
                   AND OpponentsId = @opponents_id
                   AND ((@ground_id = 0) OR (locationid = @ground_id))
                   AND ((@homecountry_id = 0) OR (m.homecountryid = @homecountry_id))
                   AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                   AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
                   AND ((@season = '0') OR (@season = seriesDate))
                   and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
                   and ((@matchresult = 0) OR (emd.Result & @matchresult)))
    select T.Name                          team,
           O.Name                          opponents,
           COALESCE(games.played, 0)       played,
           COALESCE(wins.wins, 0)          wins,
           COALESCE(losses.lost, 0)        lost,
           COALESCE(ties.tied, 0)          tied,
           COALESCE(draws.drawn, 0)        drawn,
           COALESCE(totals.innings, 0)     innings,
           COALESCE(totals.runs, 0)        totalruns,
           COALESCE(totals.wicketslost, 0) wicketslost,
           COALESCE(totals.avg, 0)         avg,
           COALESCE(totals.rpo, 0)         rpo,
           ''                              CountryName,
           ''                              SeriesDate,
           ''                              MatchStartYear,
           ''                              KnownAs
    from (select m.MatchType, teamid, OpponentsId, count(*) played
      from matches as m
               join ExtraMatchDetails emd on m.Id = emd.MatchId
          where m.matchtype = @match_type
            AND OpponentsId = @opponents_id
            AND ((@ground_id = 0) OR (locationid = @ground_id))
            AND ((@homecountry_id = 0) OR (m.homecountryid = @homecountry_id))
            AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
            AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
            AND ((@season = '0') OR (@season = seriesDate))
            and ((@homeOrAway = 0) OR (emd.HomeAway = @homeOrAway))
            and ((@matchResult = 0) OR (emd.Result = @matchResult))
          group by OpponentsId, teamid, m.MatchType) as games
             left join (select tmp.TeamId,
                               tmp.OpponentsId,
                               count(*)                                       innings,
                               sum(total)                                     runs,
                               sum(wickets)                                   wicketslost,
                               truncate(sum(total) / sum(wickets), 2)         avg,
                               truncate(sum(total) / sum(BallsBowled) * 6, 2) rpo
                        from tmp
                                 join matches m on m.Id = tmp.Id
                                 join Innings i on tmp.Id = i.MatchId
                        where tmp.TeamId = i.TeamId
                        group by tmp.TeamId, tmp.OpponentsId) as totals
                       on totals.TeamId = games.TeamId
                           and totals.OpponentsId = games.OpponentsId
             left join (select teamid, OpponentsId, count(*) wins
                        from tmp
                        where result = 1
                        group by teamid, OpponentsId) as wins
                       on wins.TeamId = games.TeamId
                           and wins.OpponentsId = games.OpponentsId
             left join (select teamid, OpponentsId, count(*) lost
                        from tmp
                        where result = 2
                        group by teamid, OpponentsId) as losses
                       on losses.TeamId = games.TeamId
                           and losses.OpponentsId = games.OpponentsId
             left join (select teamid, OpponentsId, count(*) drawn
                        from tmp
                        where result = 4
                        group by teamid, OpponentsId) as draws
                       on draws.TeamId = games.TeamId
                           and draws.OpponentsId = games.OpponentsId
             left join (select teamid, OpponentsId, count(*) tied
                        from tmp
                        where result = 8
                        group by teamid, OpponentsId) as ties
                       on ties.TeamId = draws.TeamId
                           and ties.OpponentsId = games.OpponentsId
             join teams T on T.Id = games.TeamId and T.matchtype = games.MatchType
             join teams O on O.Id = games.OpponentsId and O.matchtype = games.MatchType

    order by (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'ASC' THEN played END),
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'DESC' THEN played END) DESC,
             (CASE WHEN @sort_by = 9 AND @sort_direction = 'ASC' THEN wins END),
             (CASE WHEN @sort_by = 9 AND @sort_direction = 'DESC' THEN wins END) DESC,
             (CASE WHEN @sort_by = 10 AND @sort_direction = 'ASC' THEN lost END),
             (CASE WHEN @sort_by = 10 AND @sort_direction = 'DESC' THEN lost END) DESC,
             (CASE WHEN @sort_by = 11 AND @sort_direction = 'ASC' THEN tied END),
             (CASE WHEN @sort_by = 11 AND @sort_direction = 'DESC' THEN tied END) DESC,
             (CASE WHEN @sort_by = 12 AND @sort_direction = 'ASC' THEN drawn END),
             (CASE WHEN @sort_by = 12 AND @sort_direction = 'DESC' THEN drawn END) DESC,
             (CASE WHEN @sort_by = 19 AND @sort_direction = 'ASC' THEN games.OpponentsId END),
             (CASE WHEN @sort_by = 19 AND @sort_direction = 'DESC' THEN games.OpponentsId END) DESC,
             games.OpponentsId, team;
end;

