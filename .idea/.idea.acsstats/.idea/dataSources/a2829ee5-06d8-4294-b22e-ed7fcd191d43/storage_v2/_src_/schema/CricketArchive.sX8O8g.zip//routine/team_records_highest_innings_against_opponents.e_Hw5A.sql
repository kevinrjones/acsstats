create
    definer = cricketarchive@`%` procedure team_records_highest_innings_against_opponents(IN match_type varchar(20),
                                                                                          IN opponents_id int,
                                                                                          IN ground_id int,
                                                                                          IN homecountry_id int,
                                                                                          IN homeOrAway int,
                                                                                          IN startDate mediumtext,
                                                                                          IN endDate mediumtext,
                                                                                          IN season varchar(10),
                                                                                          IN matchResult int,
                                                                                          IN minimum_total int,
                                                                                          IN sort_by int,
                                                                                          IN sort_direction varchar(5))
begin

    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @minimum_total = minimum_total;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;


    select team.name as team,
           opp.name  as opponents,
           m.matchtitle,
           m.location,
           m.matchdate,
           m.resultstring,
           i.total      totalruns,
           i.wickets    totalwickets,
           i.BallsBowled,
           i.BallsPerOver
    from matches as m
             join innings as i on m.id = i.matchid
             join teams as team on i.teamid = team.id and m.matchtype = team.matchtype
             join teams as opp on i.opponentsid = opp.id and m.matchtype = opp.matchtype
             join extramatchdetails emd
                                   on emd.MatchId = m.Id
                                       and emd.TeamId = team.Id
                                       and ((@matchResult = 0) OR (emd.result & @matchResult))
                                       and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
    where m.matchtype = @match_type
      and i.opponentsid = @opponents_id
      and i.total >= @minimum_total
      AND ((@ground_id = 0) OR (locationid = @ground_id))
      AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
      AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
      AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
      AND ((@season = '0') OR (@season = seriesDate))

    order by (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN totalruns END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN totalruns END) DESC,
             totalruns desc;
end;

