create
    definer = cricketarchive@`%` procedure batting_individual_career_records_by_match(IN team_id int,
                                                                                      IN opponents_id int,
                                                                                      IN match_type varchar(20),
                                                                                      IN ground_id int,
                                                                                      IN homecountry_id int,
                                                                                      IN homeOrAway int,
                                                                                      IN startDate mediumtext,
                                                                                      IN endDate mediumtext,
                                                                                      IN season varchar(10),
                                                                                      IN matchResult int,
                                                                                      IN runs_limit int, IN sort_by int,
                                                                                      IN sort_direction varchar(5))
begin
    set @team_id = team_id;
    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @runs_limit = runs_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;
    
    
    select FullName,
           SortNamePart,
           bat1,
           bat2,
           playerscore,
           notout,
           position,
           b    as balls,
           f    as fours,
           s    as sixes,
           m    as minutes,
           captain,
           wicketkeeper,
           team,
           opponents,
           matchdesignator,
           MatchStartDate matchDate,
           seriesdate,
           inum as inningsnumber,
           dismissal,
           bowler,
           fielder,
           ground
    from (
             select players.FullName,
                    players.SortNamePart,
                    bd1.Score                                              bat1,
                    bd2.Score                                              bat2,
                    bd1.Score + COALESCE(bd2.Score, 0)                  as playerscore,
                    false                                               as notout,
                    0                                                   as position,
                    bd1.Balls + COALESCE(bd2.Balls, 0)                  as b,
                    bd1.Fours + COALESCE(bd2.Fours, 0)                  as f,
                    bd1.Sixes + COALESCE(bd2.Sixes, 0)                  as s,
                    COALESCE(bd1.Minutes, 0) + COALESCE(bd2.Minutes, 0) as m,
                    bd1.captain,
                    bd1.wicketkeeper,
                    T.Name                                                 team,
                    O.Name                                                 opponents,
                    matches.matchdesignator,
                    matches.MatchStartDate,
                    matches.seriesdate,
                    0                                                   as inum,
                    ''                                                  as dismissal,
                    bowler.fullname                                     as bowler,
                    fielder.fullname                                    as fielder,
                    g.KnownAs                                           as ground
             from battingdetails bd1
                      join teams t on T.id = bd1.teamid
                      join teams o on O.id = bd1.opponentsid
                      join players on players.id = bd1.PlayerId
                      left outer join players bowler on bowler.playerid = bd1.bowlerid
                      left outer join players fielder on fielder.playerid = bd1.fielderid
                      join matches on matches.id = bd1.matchid
                      join grounds g on g.Id = matches.LocationId
                      left outer join BattingDetails bd2 on bd1.MatchId = bd2.MatchId and bd1.PlayerId = bd2.PlayerId
                 and bd1.matchtype = @match_type
                 and t.MatchType = bd1.MatchType
                 and o.matchtype = bd1.MatchType
                 and matches.matchtype = bd1.MatchType
                 and g.MatchType = bd1.MatchType
                 AND ((@ground_id = 0) OR (g.Id = @ground_id))
                 AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
                 AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                 AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
                 AND ((@season = '0') OR (@season = matches.seriesDate))
                 AND ((@opponents_id = 0) OR (@opponents_id = bd1.OpponentsId))
                 AND ((@team_id = 0) OR (@team_id = bd1.TeamId))
                      join extramatchdetails emd
                                   on emd.MatchId = bd1.MatchId
                                       and emd.TeamId = bd1.TeamId
                                       and ((@matchResult = 0) OR (emd.result & @matchResult))
                                       and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))


             where bd1.InningsNumber = 1
               and bd2.InningsNumber = 2
               and bd1.Score + COALESCE(bd2.Score, 0) >= @runs_limit


             order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN players.sortnamepart END),
                      (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN players.sortnamepart END) DESC,
                      (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
                      (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
                      (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
                      (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
                      (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN playerscore END),
                      (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN playerscore END) DESC,
                      (CASE WHEN @sort_by = 6 AND @sort_direction = 'ASC' THEN b END),
                      (CASE WHEN @sort_by = 6 AND @sort_direction = 'DESC' THEN b END) DESC,
                      (CASE WHEN @sort_by = 33 AND @sort_direction = 'ASC' THEN f END),
                      (CASE WHEN @sort_by = 33 AND @sort_direction = 'DESC' THEN f END) DESC,
                      (CASE WHEN @sort_by = 34 AND @sort_direction = 'ASC' THEN s END),
                      (CASE WHEN @sort_by = 34 AND @sort_direction = 'DESC' THEN s END) DESC,
                      (CASE WHEN @sort_by = 35 AND @sort_direction = 'ASC' THEN inum END),
                      (CASE WHEN @sort_by = 35 AND @sort_direction = 'DESC' THEN inum END) DESC,
                      (CASE WHEN @sort_by = 20 AND @sort_direction = 'ASC' THEN KnownAs END),
                      (CASE WHEN @sort_by = 20 AND @sort_direction = 'DESC' THEN KnownAs END) DESC,
                      (CASE WHEN @sort_by = 17 AND @sort_direction = 'ASC' THEN MatchStartDateAsOffset END),
                      (CASE WHEN @sort_by = 17 AND @sort_direction = 'DESC' THEN MatchStartDateAsOffset END) DESC,
                      (CASE WHEN @sort_by = 36 AND @sort_direction = 'ASC' THEN bat1 END),
                      (CASE WHEN @sort_by = 36 AND @sort_direction = 'DESC' THEN bat1 END) DESC,
                      (CASE WHEN @sort_by = 37 AND @sort_direction = 'ASC' THEN bat2 END),
                      (CASE WHEN @sort_by = 37 AND @sort_direction = 'DESC' THEN bat2 END) DESC,
                      (CASE WHEN @sort_by = 38 AND @sort_direction = 'ASC' THEN m END),
                      (CASE WHEN @sort_by = 38 AND @sort_direction = 'DESC' THEN m END) DESC,
                      playerscore desc, NotOut desc, MatchStartDateAsOffset) as matchdetails;
end;

