create
    definer = cricketarchive@`%` procedure bowling_individual_career_records_by_year_complete(IN match_type VARCHAR(20),
                                                                                              IN ground_id INT,
                                                                                              IN homecountry_id INT,
                                                                                              IN homeOrAway INT,
                                                                                              IN startDate LONG,
                                                                                              IN endDate LONG,
                                                                                              IN season VARCHAR(10),
                                                                                              IN matchResult INT,
                                                                                              IN wickets_limit INT,
                                                                                              IN sort_by INT,
                                                                                              IN sort_direction VARCHAR(5))
begin
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @wickets_limit = wickets_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;

    with tmp_bowl as (select bd.MatchId,
                             bd.matchtype,
                             bd.playerid,
                             bd.didbowl,
                             bd.inningsnumber,
                             bd.teamid,
                             bd.opponentsid,
                             bd.balls,
                             bd.maidens,
                             bd.runs,
                             bd.wickets,
                             bd.noballs,
                             bd.wides,
                             bd.dots,
                             bd.fours,
                             bd.sixes,
                             bd.TenFor,
                             m.MatchStartYear
                      from (select *
                            from bowlingdetails
                            where matchid in
                                  (select id
                                   from matches
                                   where id in (select matchid from battingdetails)
                                     and matchtype = @match_type
                                     AND ((@ground_id = 0) OR (groundid = @ground_id))
                                     AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
                                     AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                                     AND ((@endDate = 0) OR (@endDate >= matchStartDateAsOffset))
                                     AND ((@season = '0') OR (@season = seriesDate))
                                  )) as bd
                               join matches m on m.id = bd.matchid
                               join extramatchdetails emd1
                                    on emd1.MatchId = m.Id
                                        and emd1.TeamId = bd.TeamId
                                        and ((@matchresult = 0) OR (emd1.result & @matchresult))
                               join extramatchdetails emd2
                                    on emd2.MatchId = m.Id
                                        and emd2.TeamId = bd.TeamId
                                        and ((@homeOrAway = 0) OR (emd2.HomeAway & @homeOrAway))
    )
    select players.fullname                                                                    name,
           teams.teams                                                                         team,
           ''                                                                                  opponents,
           players.sortnamepart,
           innings.MatchStartYear                                                              Year,
           ''                                                                                  Ground,
           innings.matches,
           innings.innings,
           innings.balls,
           innings.maidens,
           innings.runs,
           innings.wickets,
           CAST(TRUNCATE(innings.Runs / CAST(innings.wickets AS DECIMAL), 2) AS DECIMAL(7, 2)) 'Avg',
           innings.noballs,
           innings.wides,
           innings.dots,
           innings.fours,
           innings.sixes,
           fives.fivefor,
           tens.tenfor,
           bbi.bbw                                                                             bbiw,
           bbi.bbr                                                                             bbir,
           bbm.bbw                                                                             bbmw,
           bbm.bbr                                                                             bbmr,
           ''                                                                                  CountryName
    from (select count(case when inningsnumber = 1 then 1 end) matches,
                 sum(didbowl) as                               innings,
                 MatchStartYear,
                 playerid,
                 MatchType,
                 SUM(balls)                                    balls,
                 SUM(maidens)                                  maidens,
                 SUM(wickets)                                  wickets,
                 SUM(runs)                                     runs,
                 SUM(wides)                                    wides,
                 SUM(noballs)                                  noballs,
                 SUM(fours)                                    fours,
                 SUM(dots)                                     dots,
                 SUM(sixes)                                    sixes
          from tmp_bowl
          group by playerid, MatchStartYear, MatchType
          having sum(didbowl) > 0
             and sum(wickets) > -1) as innings
             JOIN players ON players.id = innings.playerid
             join
         (select pt.playerid, t.matchtype, GROUP_CONCAT(t.name SEPARATOR ', ') as teams
          from playersteams pt
                   join teams t on pt.teamid = t.id
          group by pt.playerid, t.matchtype)
             as teams on teams.playerid = innings.playerid and teams.matchtype = innings.MatchType
             left outer JOIN
         (SELECT playerid,
                 MatchStartYear,
                 SUM(wickets > 4) fivefor
          FROM tmp_bowl
          WHERE didbowl = 1
          GROUP BY playerid, MatchStartYear) fives
         ON fives.playerid = innings.playerid and fives.MatchStartYear = innings.MatchStartYear
             LEFT OUTER JOIN
         (SELECT DISTINCT BD.Playerid,
                          BD.MatchStartYear,
                          wickets.wickets bbw,
                          runs.runs       bbr
          FROM tmp_bowl AS bd
                   JOIN (SELECT playerid,
                                MatchStartYear,
                                MAX(wickets) wickets
                         FROM tmp_bowl
                         WHERE balls > 0
                           and didbowl = 1
                         GROUP BY playerid, MatchStartYear
          ) AS wickets
                        ON wickets.playerid = BD.playerid
                   JOIN (SELECT playerid,
                                MatchStartYear,
                                MIN(runs) runs,
                                wickets
                         FROM tmp_bowl
                         WHERE balls > 0
                           and didbowl = 1
                         GROUP BY wickets, playerid, MatchStartYear
                         HAVING wickets = MAX(wickets)) AS runs
                        ON runs.wickets = wickets.wickets
                            AND runs.playerid = wickets.playerid
                            AND runs.playerid = BD.playerid
                            AND Runs.MatchStartYear = wickets.MatchStartYear
                            AND Runs.MatchStartYear = bd.MatchStartYear
          WHERE bd.matchtype = MatchType
         ) bbi
         ON bbi.playerid = innings.playerid and bbi.MatchStartYear = innings.MatchStartYear
             LEFT OUTER JOIN
         (SELECT runs.playerid,
                 runs.wickets   bbw,
                 runs.MatchStartYear,
                 MIN(runs.runs) bbr
          FROM (SELECT playerid,
                       MatchStartYear,
                       MAX(wickets) as wickets
                FROM (SELECT playerid,
                             MatchStartYear,
                             SUM(wickets) wickets
                      FROM tmp_bowl
                      GROUP BY playerid, MatchStartYear, matchid) as wicketsruns
                GROUP BY playerid, MatchStartYear) wickets
                   JOIN (SELECT playerid,
                                MatchStartYear,
                                wickets,
                                runs
                         FROM (SELECT playerid,
                                      MatchStartYear,
                                      SUM(wickets) wickets,
                                      SUM(runs)    runs
                               FROM tmp_bowl
                               WHERE didbowl = 1
                               GROUP BY playerid, matchid, MatchStartYear
                               ORDER BY playerid) as wicketsruns
                         ORDER BY playerid, MatchStartYear) as runs
                        ON wickets.wickets = runs.wickets
                            AND wickets.playerid = runs.playerid
                            AND wickets.MatchStartYear = runs.MatchStartYear
          GROUP BY runs.playerid, runs.wickets, runs.MatchStartYear) bbm
         ON bbm.playerid = innings.playerid and bbm.MatchStartYear = innings.MatchStartYear
             left outer JOIN
         (SELECT PlayerId, MatchStartYear, count(*) tenfor
          FROM tmp_bowl
          WHERE inningsnumber = 1
            and TenFor = true
          group by PlayerId, MatchStartYear) tens
         ON tens.playerid = innings.playerid and
            tens.MatchStartYear = innings.MatchStartYear

    where innings.Wickets >= @wickets_limit

    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN sortnamepart END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN sortnamepart END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'ASC' THEN matches END),
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'DESC' THEN matches END) DESC,
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'ASC' THEN innings END),
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'DESC' THEN innings END) DESC,
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'ASC' THEN balls END),
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'DESC' THEN balls END) DESC,
             (CASE WHEN @sort_by = 47 AND @sort_direction = 'ASC' THEN maidens END),
             (CASE WHEN @sort_by = 47 AND @sort_direction = 'DESC' THEN maidens END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN runs END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN runs END) DESC,
             (CASE WHEN @sort_by = 5 AND @sort_direction = 'ASC' THEN wickets END),
             (CASE WHEN @sort_by = 5 AND @sort_direction = 'DESC' THEN wickets END) DESC,
             (CASE WHEN @sort_by = 15 AND @sort_direction = 'ASC' THEN wides END),
             (CASE WHEN @sort_by = 15 AND @sort_direction = 'DESC' THEN wides END) DESC,
             (CASE WHEN @sort_by = 16 AND @sort_direction = 'ASC' THEN noballs END),
             (CASE WHEN @sort_by = 16 AND @sort_direction = 'DESC' THEN noballs END) DESC,
             (CASE WHEN @sort_by = 33 AND @sort_direction = 'ASC' THEN fours END),
             (CASE WHEN @sort_by = 33 AND @sort_direction = 'DESC' THEN fours END) DESC,
             (CASE WHEN @sort_by = 34 AND @sort_direction = 'ASC' THEN sixes END),
             (CASE WHEN @sort_by = 34 AND @sort_direction = 'DESC' THEN sixes END) DESC,
             (CASE WHEN @sort_by = 48 AND @sort_direction = 'ASC' THEN dots END),
             (CASE WHEN @sort_by = 48 AND @sort_direction = 'DESC' THEN dots END) DESC,
             (CASE WHEN @sort_by = 41 AND @sort_direction = 'ASC' THEN avg END),
             (CASE WHEN @sort_by = 41 AND @sort_direction = 'DESC' THEN avg END) DESC,
             (CASE WHEN @sort_by = 49 AND @sort_direction = 'ASC' THEN tenfor END),
             (CASE WHEN @sort_by = 49 AND @sort_direction = 'DESC' THEN tenfor END) DESC,
             (CASE WHEN @sort_by = 50 AND @sort_direction = 'ASC' THEN fivefor END),
             (CASE WHEN @sort_by = 50 AND @sort_direction = 'DESC' THEN fivefor END) DESC,
             (CASE WHEN @sort_by = 45 AND @sort_direction = 'ASC' THEN bbiw END),
             (CASE WHEN @sort_by = 45 AND @sort_direction = 'DESC' THEN bbiw END) DESC,
             (CASE WHEN @sort_by = 45 AND @sort_direction = 'ASC' THEN bbir END) DESC,
             (CASE WHEN @sort_by = 45 AND @sort_direction = 'DESC' THEN bbir END),
             (CASE WHEN @sort_by = 46 AND @sort_direction = 'ASC' THEN bbmw END),
             (CASE WHEN @sort_by = 46 AND @sort_direction = 'DESC' THEN bbmw END) DESC,
             (CASE WHEN @sort_by = 46 AND @sort_direction = 'ASC' THEN bbmr END) DESC,
             (CASE WHEN @sort_by = 46 AND @sort_direction = 'DESC' THEN bbmr END),
             (CASE WHEN @sort_by = 7 AND @sort_direction = 'ASC' THEN year END),
             (CASE WHEN @sort_by = 7 AND @sort_direction = 'DESC' THEN year END) DESC,
             year, wickets desc, runs;
end;

