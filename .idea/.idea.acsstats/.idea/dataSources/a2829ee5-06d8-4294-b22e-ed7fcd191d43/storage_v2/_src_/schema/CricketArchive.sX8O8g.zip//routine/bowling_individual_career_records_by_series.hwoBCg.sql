create
    definer = cricketarchive@`%` procedure bowling_individual_career_records_by_series(IN team_id INT,
                                                                                       IN opponents_id INT,
                                                                                       IN match_type VARCHAR(20),
                                                                                       IN ground_id INT,
                                                                                       IN homecountry_id INT,
                                                                                       IN homeOrAway INT,
                                                                                       IN startDate LONG,
                                                                                       IN endDate LONG,
                                                                                       IN season VARCHAR(10),
                                                                                       IN matchResult INT,
                                                                                       IN wickets_limit INT,
                                                                                       IN sort_by INT,
                                                                                       IN sort_direction VARCHAR(5))
begin
    set @team_id = team_id;
    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @wickets_limit = wickets_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;

    with tmp_bowl as (select bd.MatchId,
                             bd.matchtype,
                             bd.playerid,
                             bd.didbowl,
                             bd.inningsnumber,
                             bd.teamid,
                             bd.opponentsid,
                             bd.balls,
                             bd.maidens,
                             bd.runs,
                             bd.wickets,
                             bd.noballs,
                             bd.wides,
                             bd.dots,
                             bd.fours,
                             bd.sixes,
                             bd.TenFor,
                             m.SeriesNumber,
                             m.SeriesDate
                      from (select *
                            from bowlingdetails
                            where matchid in
                                  (select id
                                   from matches
                                   where id in (select matchid from battingdetails)
                                     and matchtype = @match_type
                                     AND ((@team_id = 0) OR (teamid = @team_id))
                                     AND ((@opponents_id = 0) OR (opponentsid = @opponents_id))
                                     AND ((@ground_id = 0) OR (groundid = @ground_id))
                                     AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
                                     AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                                     AND ((@endDate = 0) OR (@endDate >= matchStartDateAsOffset))
                                     AND ((@season = '0') OR (@season = seriesDate))
                                  )) as bd
                               join matches m on m.id = bd.matchid
                               join extramatchdetails emd1
                                    on emd1.MatchId = m.Id
                                        and emd1.TeamId = bd.TeamId
                                        and ((@matchresult = 0) OR (emd1.result & @matchresult))
                               join extramatchdetails emd2
                                    on emd2.MatchId = m.Id
                                        and emd2.TeamId = bd.TeamId
                                        and ((@homeOrAway = 0) OR (emd2.HomeAway & @homeOrAway))
    )
    select innings.SeriesDate,
           players.fullname                                                                    name,
           t.name                                                                              team,
           o.Name                                                                              opponents,
           players.sortnamepart,
           innings.matches,
           innings.innings,
           innings.balls,
           innings.maidens,
           innings.runs,
           innings.wickets,
           CAST(TRUNCATE(innings.Runs / CAST(innings.wickets AS DECIMAL), 2) AS DECIMAL(7, 2)) 'Avg',
           innings.noballs,
           innings.wides,
           innings.dots,
           innings.fours,
           innings.sixes,
           fives.fivefor,
           tens.tenfor,
           bbi.bbw                                                                             bbiw,
           bbi.bbr                                                                             bbir,
           bbm.bbw                                                                             bbmw,
           bbm.bbr                                                                             bbmr,
           ''                                                                                  Year,
           ''                                                                                  Ground,
           ''                                                                                  CountryName
    from (select count(case when inningsnumber = 1 then 1 end) matches,
                 sum(didbowl) as                               innings,
                 playerid,
                 TeamId,
                 OpponentsId,
                 SeriesNumber,
                 SeriesDate,
                 SUM(balls)                                    balls,
                 SUM(maidens)                                  maidens,
                 SUM(wickets)                                  wickets,
                 SUM(runs)                                     runs,
                 SUM(wides)                                    wides,
                 SUM(noballs)                                  noballs,
                 SUM(fours)                                    fours,
                 SUM(dots)                                     dots,
                 SUM(sixes)                                    sixes
          from tmp_bowl
          group by playerid, TeamId, OpponentsId, SeriesNumber, SeriesDate
          having sum(didbowl) > 0
             and sum(wickets) > -1) as innings
             join teams t on t.id = innings.TeamId
             join teams o on o.id = innings.OpponentsId
             JOIN players ON players.id = innings.playerid
             left outer JOIN
         (SELECT playerid,
                 SeriesNumber,
                 SUM(wickets > 4) fivefor
          FROM tmp_bowl
          WHERE didbowl = 1
          GROUP BY playerid, SeriesNumber) fives
         ON fives.playerid = innings.playerid and fives.SeriesNumber = innings.SeriesNumber
             LEFT OUTER JOIN
         (SELECT DISTINCT BD.Playerid,
                          BD.SeriesNumber,
                          wickets.wickets bbw,
                          runs.runs       bbr
          FROM tmp_bowl AS bd
                   JOIN (SELECT playerid,
                                SeriesNumber,
                                MAX(wickets) wickets
                         FROM tmp_bowl
                         WHERE balls > 0
                           and didbowl = 1
                         GROUP BY playerid, SeriesNumber
          ) AS wickets
                        ON wickets.playerid = BD.playerid
                   JOIN (SELECT playerid,
                                SeriesNumber,
                                MIN(runs) runs,
                                wickets
                         FROM tmp_bowl
                         WHERE balls > 0
                           and didbowl = 1
                         GROUP BY wickets, playerid, SeriesNumber
                         HAVING wickets = MAX(wickets)) AS runs
                        ON runs.wickets = wickets.wickets
                            AND runs.playerid = wickets.playerid
                            AND runs.playerid = BD.playerid
                            AND Runs.SeriesNumber = wickets.SeriesNumber
                            AND Runs.SeriesNumber = bd.SeriesNumber
          WHERE bd.matchtype = MatchType
         ) bbi
         ON bbi.playerid = innings.playerid and bbi.SeriesNumber = innings.SeriesNumber
             LEFT OUTER JOIN
         (SELECT runs.playerid,
                 runs.wickets   bbw,
                 runs.SeriesNumber,
                 MIN(runs.runs) bbr
          FROM (SELECT playerid,
                       SeriesNumber,
                       MAX(wickets) as wickets
                FROM (SELECT playerid,
                             SeriesNumber,
                             SUM(wickets) wickets
                      FROM tmp_bowl
                      GROUP BY playerid, SeriesNumber, matchid) as wicketsruns
                GROUP BY playerid, SeriesNumber) wickets
                   JOIN (SELECT playerid,
                                SeriesNumber,
                                wickets,
                                runs
                         FROM (SELECT playerid,
                                      SeriesNumber,
                                      SUM(wickets) wickets,
                                      SUM(runs)    runs
                               FROM tmp_bowl
                               WHERE didbowl = 1
                               GROUP BY playerid, matchid, SeriesNumber
                               ORDER BY playerid) as wicketsruns
                         ORDER BY playerid, SeriesNumber) as runs
                        ON wickets.wickets = runs.wickets
                            AND wickets.playerid = runs.playerid
                            AND wickets.SeriesNumber = runs.SeriesNumber
          GROUP BY runs.playerid, runs.wickets, runs.SeriesNumber) bbm
         ON bbm.playerid = innings.playerid and bbm.SeriesNumber = innings.SeriesNumber
             left outer JOIN
         (SELECT PlayerId, seriesnumber, count(*) tenfor
          FROM tmp_bowl
          WHERE inningsnumber = 1
            and TenFor = true
          group by PlayerId, seriesnumber) tens
         ON tens.playerid = innings.playerid and
            tens.SeriesNumber = innings.SeriesNumber

    where innings.Wickets >= @wickets_limit


    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN sortnamepart END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN sortnamepart END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN runs END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN runs END) DESC,
             (CASE WHEN @sort_by = 5 AND @sort_direction = 'ASC' THEN wickets END),
             (CASE WHEN @sort_by = 5 AND @sort_direction = 'DESC' THEN wickets END) DESC,
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'ASC' THEN balls END),
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'DESC' THEN balls END) DESC,
             (CASE WHEN @sort_by = 7 AND @sort_direction = 'ASC' THEN year END),
             (CASE WHEN @sort_by = 7 AND @sort_direction = 'DESC' THEN year END) DESC,
             SeriesDate;
end;

