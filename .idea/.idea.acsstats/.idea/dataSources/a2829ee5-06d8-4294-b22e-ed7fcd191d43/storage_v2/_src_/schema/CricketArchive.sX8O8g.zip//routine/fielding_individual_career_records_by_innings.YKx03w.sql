create
    definer = cricketarchive@`%` procedure fielding_individual_career_records_by_innings(IN team_id INT,
                                                                                         IN opponents_id INT,
                                                                                         IN match_type VARCHAR(20),
                                                                                         IN ground_id INT,
                                                                                         IN homecountry_id INT,
                                                                                         IN homeOrAway INT,
                                                                                         IN startDate LONG,
                                                                                         IN endDate LONG,
                                                                                         IN season VARCHAR(10),
                                                                                         IN matchResult INT,
                                                                                         IN dismissals_limit INT,
                                                                                         IN sort_by INT,
                                                                                         IN sort_direction VARCHAR(5))
begin

    set @team_id = team_id;
    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @dismissals_limit = dismissals_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;

    select p.FullName,
           t.Name                 team,
           f.Dismissals,
           f.CaughtF + f.CaughtWk caught,
           f.Stumped              stumpings,
           f.Caughtwk             caughtkeeper,
           f.Caughtf              caughtfielder,
           f.InningsNumber,
           o.Name                 opponents,
           g.KnownAs              Ground,
           m.MatchStartDate       matchDate
    from Fielding f
             join players p on p.id = f.PlayerId
             join teams t on t.Id = f.TeamId and t.MatchType = f.MatchType
             join teams o on o.Id = f.OpponentsId and o.MatchType = f.MatchType
             join matches m on m.id = f.MatchId
             join grounds g on g.id = m.LocationId and g.MatchType = f.MatchType
        AND ((@ground_id = 0) OR (g.id = @ground_id))
        AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
        AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
        AND ((@endDate = 0) OR (@endDate >= matchStartDateAsOffset))
        AND ((@season = '0') OR (@season = m.seriesDate))
        AND ((@opponents_id = 0) OR (@opponents_id = f.OpponentsId))
        AND ((@team_id = 0) OR (@team_id = f.TeamId))
             join extramatchdetails emd
                  on emd.MatchId = m.Id
                      and emd.TeamId = f.TeamId
                      and ((@matchResult = 0) OR (emd.result & @matchResult))
                      and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))

    where f.MatchType = @match_type
      and f.Dismissals >= @dismissals_limit
      and ((@team_id = 0) OR (f.teamid = @team_id))
      and ((@opponents_id = 0) OR (f.OpponentsId = @opponents_id))

    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN sortnamepart END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN sortnamepart END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 26 AND @sort_direction = 'ASC' THEN dismissals END),
             (CASE WHEN @sort_by = 26 AND @sort_direction = 'DESC' THEN dismissals END) DESC,
             (CASE WHEN @sort_by = 27 AND @sort_direction = 'ASC' THEN caught END),
             (CASE WHEN @sort_by = 27 AND @sort_direction = 'DESC' THEN caught END) DESC,
             (CASE WHEN @sort_by = 28 AND @sort_direction = 'ASC' THEN stumped END),
             (CASE WHEN @sort_by = 28 AND @sort_direction = 'DESC' THEN stumped END) DESC,
             (CASE WHEN @sort_by = 29 AND @sort_direction = 'ASC' THEN CaughtWk END),
             (CASE WHEN @sort_by = 29 AND @sort_direction = 'DESC' THEN CaughtWk END) DESC,
             (CASE WHEN @sort_by = 30 AND @sort_direction = 'ASC' THEN CaughtF END),
             (CASE WHEN @sort_by = 30 AND @sort_direction = 'DESC' THEN CaughtF END) DESC,
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'ASC' THEN MatchStartDateAsOffset END),
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'DESC' THEN MatchStartDateAsOffset END) DESC,
             (CASE WHEN @sort_by = 35 AND @sort_direction = 'ASC' THEN InningsNumber END),
             (CASE WHEN @sort_by = 35 AND @sort_direction = 'DESC' THEN InningsNumber END) DESC,
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'ASC' THEN KnownAs END),
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'DESC' THEN KnownAs END) DESC,
             f.Dismissals desc, m.MatchStartDateAsOffset;
end;

