create
    definer = cricketarchive@`%` procedure fow_partnership_list_by_opposition_against_opponents(IN opponents_id int,
                                                                                                IN match_type VARCHAR(20),
                                                                                                IN ground_id INT,
                                                                                                IN homecountry_id INT,
                                                                                                IN homeOrAway INT,
                                                                                                IN startDate LONG,
                                                                                                IN endDate LONG,
                                                                                                IN season VARCHAR(10),
                                                                                                IN matchResult INT,
                                                                                                IN runs_limit INT,
                                                                                                IN sort_by INT,
                                                                                                IN sort_direction VARCHAR(5))
begin

    set @opponents_id = opponents_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @runs_limit = runs_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;

    with tmp_fow as (select f.Partnership,
                            f.MatchType,
                            f.Id,
                            f.MatchId,
                            f.TeamId,
                            f.OpponentsId,
                            f.Innings,
                            f.Wicket,
                            f.PlayerIds,
                            f.PlayerNames,
                            f.CurrentScore,
                            f.Fifty,
                            f.Hundred,
                            f.Unbroken,
                            f.Multiple,
                            f.Partial
                     from (select *
                           from FallOfWickets
                           where PlayerIds != '0000000100000001'
                             and Multiple = false
                             and MatchId in
                                 (select id
                                  from matches
                                  where id in (select matchid from FallOfWickets)
                                    and matchtype = @match_type
                                    AND ((@opponents_id = 0) OR (OpponentsId = @opponents_id))
                                    AND ((@ground_id = 0) OR (LocationId = @ground_id))
                                    AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
                                    AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                                    AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
                                    AND ((@season = '0') OR (@season = seriesDate))
                                 )) as f
                              join matches m on m.id = f.matchid
                              join extramatchdetails emd
                                   on emd.MatchId = m.Id
                                       and emd.TeamId = f.TeamId
                                       and ((@matchResult = 0) OR (emd.result & @matchResult))
                                       and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
    )
    select names.PlayerIds,
           p1.FullName as  player1,
           p2.FullName as  player2,
           t.Name          Team,
           o.name          Opponents,
           totals.Inns     Innings,
           totals.NO       NotOuts,
           totals.runs,
           totals.avg,
           totals.hundreds,
           totals.fifties,
           max.Partnership HighestScore,
           max.unbroken    unbroken,
           ''              SeriesDate,
           ''              Ground,
           ''              CountryName
    from (select playerids,
                 MatchType,
                 OpponentsId,
                 count(*)                                                   Inns,
                 sum(Unbroken)                                              NO,
                 sum(Partnership)                                           runs,
                 TRUNCATE(Sum(Partnership) / (count(*) - sum(Unbroken)), 2) avg,
                 sum(Hundred)                                               hundreds,
                 sum(Fifty)                                                 fifties
          from tmp_fow
          group by playerids, MatchType, OpponentsId) as totals
             join (select distinct PlayerIds, PlayerNames, teamid from tmp_fow) as names
                  on names.Playerids = totals.PlayerIds
             join players p1 on p1.Id = substr(totals.PlayerIds, 1, 8)
             join players p2 on p2.Id = substr(totals.PlayerIds, 9, 8)
             join (Select name, id from teams) t
                  on t.Id = Names.TeamId
             join (SELECT playerids,
                          MAX(Partnership) Partnership,
                          MAX(Unbroken)    Unbroken
                   FROM (SELECT tmp_fow.playerids,
                                tmp_fow.Partnership,
                                tmp_fow.Unbroken
                         FROM tmp_fow
                                  JOIN (SELECT tmp_fow.playerids,
                                               MAX(tmp_fow.Partnership) AS partnership
                                        FROM tmp_fow
                                        GROUP BY tmp_fow.playerids) AS maxscore
                                       ON tmp_fow.Partnership = maxscore.partnership
                                           AND tmp_fow.playerids = maxscore.playerids) AS internal
                   GROUP BY internal.playerids) max
                  on max.PlayerIds = totals.PlayerIds
             join Teams o on o.Id = OpponentsId


    where runs > @runs_limit

    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN PlayerNames END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN PlayerNames END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN Opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN Opponents END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN runs END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN runs END) DESC,
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'ASC' THEN innings END),
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'DESC' THEN innings END) DESC,
             (CASE WHEN @sort_by = 40 AND @sort_direction = 'ASC' THEN HighestScore END),
             (CASE WHEN @sort_by = 40 AND @sort_direction = 'DESC' THEN HighestScore END) DESC,
             (CASE WHEN @sort_by = 41 AND @sort_direction = 'ASC' THEN avg END),
             (CASE WHEN @sort_by = 41 AND @sort_direction = 'DESC' THEN avg END) DESC,
             (CASE WHEN @sort_by = 42 AND @sort_direction = 'ASC' THEN Fifties END),
             (CASE WHEN @sort_by = 42 AND @sort_direction = 'DESC' THEN Fifties END) DESC,
             (CASE WHEN @sort_by = 43 AND @sort_direction = 'ASC' THEN Hundreds END),
             (CASE WHEN @sort_by = 43 AND @sort_direction = 'DESC' THEN Hundreds END) DESC,
             runs desc, PlayerNames;
end;

