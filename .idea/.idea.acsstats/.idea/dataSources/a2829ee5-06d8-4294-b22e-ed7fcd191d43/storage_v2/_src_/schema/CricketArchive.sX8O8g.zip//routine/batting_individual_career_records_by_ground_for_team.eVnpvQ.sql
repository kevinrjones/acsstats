create
    definer = cricketarchive@`%` procedure batting_individual_career_records_by_ground_for_team(IN team_id int,
                                                                                                IN match_type varchar(20),
                                                                                                IN ground_id int,
                                                                                                IN homecountry_id int,
                                                                                                IN homeOrAway int,
                                                                                                IN startDate mediumtext,
                                                                                                IN endDate mediumtext,
                                                                                                IN season varchar(10),
                                                                                                IN matchResult int,
                                                                                                IN runs_limit int,
                                                                                                IN sort_by int,
                                                                                                IN sort_direction varchar(5))
begin
    
    set @team_id = team_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @startdate = startDate;
    set @enddate = endDate;
    set @homeOrAway = homeOrAway;
    set @season = season;
    set @matchresult = matchResult;
    set @runs_limit = runs_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;
    
    with tmp_bat as (select bd.MatchId,
                            bd.matchtype,
                            bd.playerid,
                            bd.inningsnumber,
                            bd.dismissaltype,
                            bd.score,
                            bd.notout,
                            bd.balls,
                            bd.fours,
                            bd.sixes,
                            bd.hundred,
                            bd.fifty,
                            bd.duck,
                            bd.GroundId as locationid
                     from (select *
                           from battingdetails
                           where matchid in
                                 (select id
                                  from matches
                                  where id in (select matchid from battingdetails)
                                    and matchtype = @match_type
                                    AND ((@team_id = 0) OR (teamid = @team_id))
                                    AND ((@ground_id = 0) OR (groundid = @ground_id))
                                    AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
                                    AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                                    AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
                                    AND ((@season = '0') OR (@season = seriesDate))
                                 )) as bd
                              join matches m on m.id = bd.matchid
                              join extramatchdetails emd
                                   on emd.MatchId = bd.MatchId
                                       and emd.TeamId = bd.TeamId
                                       and ((@matchResult = 0) OR (emd.result & @matchResult))
                                       and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))

    )
    select players.fullname                                    name,
           teams.name                                          team,
           ''                                                  opponents,
           players.sortnamepart,
           innings.matches,
           innings.innings,
           innings.notouts,
           innings.runs,
           HS.score                                            highestscore,
           HS.NotOut,
           CAST(TRUNCATE(innings.runs / (CAST((Innings.Innings - innings.notOuts) AS DECIMAL)),
                         2) AS DECIMAL(7, 2))                  'Avg',
           innings.hundreds,
           innings.fifties,
           innings.ducks,
           innings.fours,
           innings.sixes,
           innings.balls,
           CONCAT(grounds.CountryName, ' - ', grounds.KnownAs) Ground,
           ''                                                  Year,
           ''                                                  CountryName
    from (select count(case when inningsnumber = 1 then 1 end)                           matches,
                 count(case when dismissaltype != 11 and dismissaltype != 14 then 1 end) innings,
                 playerid,
                 MatchType,
                 LocationId,
                 SUM(score)                                                              runs,
                 SUM(notout)                                                             notouts,
                 SUM(hundred)                                                            Hundreds,
                 SUM(fifty)                                                              Fifties,
                 SUM(duck)                                                               Ducks,
                 SUM(fours)                                                              Fours,
                 SUM(sixes)                                                              Sixes,
                 SUM(balls)                                                              Balls
          from tmp_bat
          group by playerid, MatchType, LocationId) as innings
             JOIN players ON players.id = innings.playerid
             join grounds on Grounds.Id = LocationId and grounds.MatchType = innings.MatchType
             join teams ON Teams.id = @team_id
        AND teams.matchtype = innings.MatchType
             LEFT JOIN

         (SELECT playerid,
                 LocationId,
                 MAX(Score)  Score,
                 MAX(NotOut) NotOut
          FROM (SELECT battingdetails.playerid,
                       battingdetails.score,
                       battingdetails.notout,
                       battingdetails.LocationId
                FROM tmp_bat as battingdetails
                         JOIN (SELECT battingdetails.playerid,
                                      battingdetails.LocationId,
                                      MAX(battingdetails.Score) AS score
                               FROM tmp_bat as battingdetails
                               GROUP BY battingdetails.playerid,
                                        battingdetails.LocationId,
                                        battingdetails.playerid) AS maxscore
                              ON battingdetails.score = maxscore.score
                                  AND battingdetails.playerid = maxscore.playerid
                                  AND battingdetails.LocationId = maxscore.LocationId) AS internal
          GROUP BY internal.playerid, internal.LocationId) AS HS
         ON HS.playerid = innings.playerid and hs.LocationId = innings.LocationId

    where innings.runs >= @runs_limit

    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN sortnamepart END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN sortnamepart END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN opponents END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN runs END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN runs END) DESC,
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'ASC' THEN Balls END),
             (CASE WHEN @sort_by = 6 AND @sort_direction = 'DESC' THEN Balls END) DESC,
             (CASE WHEN @sort_by = 7 AND @sort_direction = 'ASC' THEN year END),
             (CASE WHEN @sort_by = 7 AND @sort_direction = 'DESC' THEN year END) DESC,
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'ASC' THEN innings.matches END),
             (CASE WHEN @sort_by = 8 AND @sort_direction = 'DESC' THEN innings.matches END) DESC,
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'ASC' THEN innings.innings END),
             (CASE WHEN @sort_by = 32 AND @sort_direction = 'DESC' THEN innings.innings END) DESC,
             (CASE WHEN @sort_by = 33 AND @sort_direction = 'ASC' THEN Fours END),
             (CASE WHEN @sort_by = 33 AND @sort_direction = 'DESC' THEN Fours END) DESC,
             (CASE WHEN @sort_by = 34 AND @sort_direction = 'ASC' THEN Sixes END),
             (CASE WHEN @sort_by = 34 AND @sort_direction = 'DESC' THEN Sixes END) DESC,
             (CASE WHEN @sort_by = 39 AND @sort_direction = 'ASC' THEN innings.notouts END),
             (CASE WHEN @sort_by = 39 AND @sort_direction = 'DESC' THEN innings.notouts END) DESC,
             (CASE WHEN @sort_by = 40 AND @sort_direction = 'ASC' THEN highestscore END),
             (CASE WHEN @sort_by = 40 AND @sort_direction = 'DESC' THEN highestscore END) DESC,
             (CASE WHEN @sort_by = 41 AND @sort_direction = 'ASC' THEN Avg END),
             (CASE WHEN @sort_by = 41 AND @sort_direction = 'DESC' THEN Avg END) DESC,
             (CASE WHEN @sort_by = 42 AND @sort_direction = 'ASC' THEN Fifties END),
             (CASE WHEN @sort_by = 42 AND @sort_direction = 'DESC' THEN Fifties END) DESC,
             (CASE WHEN @sort_by = 43 AND @sort_direction = 'ASC' THEN Hundreds END),
             (CASE WHEN @sort_by = 43 AND @sort_direction = 'DESC' THEN Hundreds END) DESC,
             (CASE WHEN @sort_by = 44 AND @sort_direction = 'ASC' THEN Ducks END),
             (CASE WHEN @sort_by = 44 AND @sort_direction = 'DESC' THEN Ducks END) DESC,
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'ASC' THEN KnownAs END),
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'DESC' THEN KnownAs END) DESC,
             KnownAs, SortNamePart;

end;

