create
    definer = cricketarchive@`%` procedure fow_partnership_list_by_match(IN team_id INT, IN opponent_id INT,
                                                                         IN match_type VARCHAR(20), IN ground_id INT,
                                                                         IN homecountry_id INT, IN homeOrAway INT,
                                                                         IN startDate LONG, IN endDate LONG,
                                                                         IN season VARCHAR(10), IN matchResult INT,
                                                                         IN runs_limit INT, IN sort_by INT,
                                                                         IN sort_direction VARCHAR(5))
begin

    set @team_id = team_id;
    set @opponents_id = opponent_id;
    set @match_type = match_type;
    set @ground_id = ground_id;
    set @homecountry_id = homecountry_id;
    set @homeOrAway = homeOrAway;
    set @startdate = startDate;
    set @enddate = endDate;
    set @season = season;
    set @matchresult = matchResult;
    set @runs_limit = runs_limit;
    set @sort_by = sort_by;
    set @sort_direction = sort_direction;

    with tmp_fow1 as (select f.Partnership,
                             f.MatchType,
                             f.Id,
                             f.MatchId,
                             f.TeamId,
                             f.OpponentsId,
                             f.Innings,
                             f.Wicket,
                             f.PlayerIds,
                             f.PlayerNames,
                             f.CurrentScore,
                             f.Fifty,
                             f.Hundred,
                             f.Unbroken,
                             f.Multiple,
                             f.Partial
                      from (select *
                            from FallOfWickets
                            where MatchId in
                                  (select id
                                   from matches
                                   where id in (select matchid from FallOfWickets)
                                     and matchtype = @match_type
                                     AND ((@team_id = 0) OR (teamid = @team_id))
                                     AND ((@opponents_id = 0) OR (OpponentsId = @opponents_id))
                                     AND ((@ground_id = 0) OR (LocationId = @ground_id))
                                     AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
                                     AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                                     AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
                                     AND ((@season = '0') OR (@season = seriesDate))
                                  )) as f
                               join matches m on m.id = f.matchid
                               join extramatchdetails emd
                                    on emd.MatchId = m.Id
                                        and emd.TeamId = f.TeamId
                                        and ((@matchResult = 0) OR (emd.result & @matchResult))
                                        and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
                      where Innings = 1
    ),
         tmp_fow2 as (select f.Partnership,
                             f.MatchType,
                             f.Id,
                             f.MatchId,
                             f.TeamId,
                             f.OpponentsId,
                             f.Innings,
                             f.Wicket,
                             f.PlayerIds,
                             f.PlayerNames,
                             f.CurrentScore,
                             f.Fifty,
                             f.Hundred,
                             f.Unbroken,
                             f.Multiple,
                             f.Partial
                      from (select *
                            from FallOfWickets
                            where MatchId in
                                  (select id
                                   from matches
                                   where id in (select matchid from FallOfWickets)
                                     and matchtype = @match_type
                                     AND ((@team_id = 0) OR (teamid = @team_id))
                                     AND ((@opponents_id = 0) OR (OpponentsId = @opponents_id))
                                     AND ((@ground_id = 0) OR (LocationId = @ground_id))
                                     AND ((@homecountry_id = 0) OR (homecountryid = @homecountry_id))
                                     AND ((@startdate = 0) OR (@startdate <= matchStartDateAsOffset))
                                     AND ((@enddate = 0) OR (@enddate >= matchStartDateAsOffset))
                                     AND ((@season = '0') OR (@season = seriesDate))
                                  )) as f
                               join matches m on m.id = f.matchid
                               join extramatchdetails emd
                                    on emd.MatchId = m.Id
                                        and emd.TeamId = f.TeamId
                                        and ((@matchResult = 0) OR (emd.result & @matchResult))
                                        and ((@homeOrAway = 0) OR (emd.HomeAway & @homeOrAway))
                      where Innings = 2
         )
    select pid                               playerids,
           T.name                            team,
           o.Name                            Opponents,
           p1.FullName as                    player1,
           p2.FullName as                    player2,
           coalesce(p1, 0) + COALESCE(p2, 0) runs,
           no1                               unbroken1,
           coalesce(no2, false)              unbroken2,
           g.KnownAs,
           m.MatchStartDate
    from (select tmp_fow1.Innings     i1,
                 tmp_fow2.Innings     i2,
                 tmp_fow1.PlayerIds   pid,
                 tmp_fow1.MatchId     matchid,
                 tmp_fow1.TeamId      tid,
                 tmp_fow1.OpponentsId oid,
                 tmp_fow1.PlayerNames playernames,
                 tmp_fow1.partnership p1,
                 tmp_fow2.partnership p2,
                 tmp_fow1.Unbroken    no1,
                 tmp_fow2.Unbroken    no2
          from tmp_fow1
                   left join tmp_fow2 on tmp_fow1.PlayerIds = tmp_fow2.PlayerIds and tmp_fow1.MatchId = tmp_fow2.MatchId
          where not tmp_fow1.Multiple
          union ALL
          select tmp_fow1.Innings,
                 tmp_fow2.Innings,
                 tmp_fow2.PlayerIds,
                 tmp_fow2.PlayerNames,
                 tmp_fow2.MatchId     matchid,
                 tmp_fow2.TeamId      tid,
                 tmp_fow2.OpponentsId oid,
                 tmp_fow1.partnership,
                 tmp_fow2.partnership,
                 tmp_fow1.Unbroken    no1,
                 tmp_fow2.Unbroken    no2
          from tmp_fow1
                   right join tmp_fow2
                              on tmp_fow1.PlayerIds = tmp_fow2.PlayerIds and tmp_fow1.MatchId = tmp_fow2.MatchId
          where not tmp_fow2.Multiple) result
             join players p1 on p1.Id = substr(result.pid, 1, 8)
             join players p2 on p2.Id = substr(result.pid, 9, 8)
             join Matches m on m.id = matchid
             join grounds g on g.id = m.LocationId
             join teams t on t.Id = tid
             join teams o on o.Id = oid

    where coalesce(p1, 0) + COALESCE(p2, 0) > @runs_limit

    order by (CASE WHEN @sort_by = 1 AND @sort_direction = 'ASC' THEN PlayerNames END),
             (CASE WHEN @sort_by = 1 AND @sort_direction = 'DESC' THEN PlayerNames END) DESC,
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'ASC' THEN team END),
             (CASE WHEN @sort_by = 2 AND @sort_direction = 'DESC' THEN team END) DESC,
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'ASC' THEN Opponents END),
             (CASE WHEN @sort_by = 3 AND @sort_direction = 'DESC' THEN Opponents END) DESC,
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'ASC' THEN runs END),
             (CASE WHEN @sort_by = 4 AND @sort_direction = 'DESC' THEN runs END) DESC,
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'ASC' THEN KnownAs END),
             (CASE WHEN @sort_by = 20 AND @sort_direction = 'DESC' THEN KnownAs END) DESC,
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'ASC' THEN MatchStartDateAsOffset END),
             (CASE WHEN @sort_by = 17 AND @sort_direction = 'DESC' THEN MatchStartDateAsOffset END) DESC,
             runs desc, MatchStartDateAsOffset, PlayerNames;
end;

